
# DigitalGov Chrome Extension
### v0.1

Developed by DigitalGov https://.digitalgov.gov/

---

## Resources for building Chrome extensions

Getting Started: Building a Chrome Extension
https://developer.chrome.com/extensions/getstarted

Extensions API
https://developer.chrome.com/extensions/manifest

How to make an Extension:
https://robots.thoughtbot.com/how-to-make-a-chrome-extension

How to Create a Chrome Extension in 10 Minutes Flat
https://www.sitepoint.com/create-chrome-extension-10-minutes-flat/
